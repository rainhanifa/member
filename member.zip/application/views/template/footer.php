    <div class="footer">
        <div class="container">
            <div class="col-md-3 box_1">
                <img src="<?php echo base_url("assets");?>/images/f_logo.png" alt=""/>
                <p>© 2015 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
            </div>
            <div class="col-md-3 box_2">
                <h4>Quick Links</h4>
                <ul class="list_2">
                    <li><a href="<?php echo base_url();?>">Home</a></li>
                    <li><a href="<?php echo base_url("about");?>">About Us</a></li>
                    <li><a href="<?php echo base_url("service");?>">Service</a></li>
                    <li><a href="<?php echo base_url("store/theme");?>">Theme</a></li>
                    <li><a href="<?php echo base_url("promo");?>">Promo</a></li>
                    <li><a href="<?php echo base_url("reseller");?>">Reseller</a></li>
                </ul>
                <ul class="list_2">
                    <li><a href="faq.html">Faq</a></li>
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
                <div class="clearfix"> </div>
            </div>
            <div class="col-md-3 box_2">
                <h4>Contact Us</h4>
                <address class="address">
                  <dl>
                     <dt></dt>
                     <dd>Address : <span>3598 But I must explain to you how all this mistaken</span></dd>
                     <dd>E-mail : <a href="mailto@example.com">info(at)hosting.com</a></dd>
                     <dd>Call : <span> +1 800 547 5478</span></dd>
                  </dl>
               </address>
            </div>
            <div class="col-md-3 box_2">
                <h4>Social Media</h4>
                <ul class="footer_social">
                  <li><a href=""> <i class="fb"> </i> </a></li>
                  <li><a href=""><i class="tw"> </i> </a></li>
                  <li><a href=""><i class="linkedin"> </i> </a></li>
                  <li><a href=""><i class="google"> </i> </a></li>
               </ul>
            </div>
        </div>
    </div>
        <script type="text/javascript" src="<?php echo base_url("assets");?>/js/bootstrap.min.js"></script>
</body>
</html>

