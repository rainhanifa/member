<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Voucher Website</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo base_url("assets");?>/css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url("assets");?>/js/jquery-1.11.1.min.js"></script>

<!-- Custom Theme files -->
<link href="<?php echo base_url("assets");?>/css/font-awesome.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url("assets");?>/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url("assets");?>/css/ctm_style.css" rel='stylesheet' type='text/css' />

<!-- Custom Theme files -->
<!-- webfonts -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<!-- webfonts -->

<!-- Add fancyBox main JS and CSS files -->
<script src="<?php echo base_url("assets");?>/js/jquery.magnific-popup.js" type="text/javascript"></script>
<link href="<?php echo base_url("assets");?>/css/popup.css" rel="stylesheet" type="text/css">
<script>
    $(document).ready(function() {
        $('.popup-with-zoom-anim').magnificPopup({
            type: 'inline',
            fixedContentPos: false,
            fixedBgPos: true,
            overflowY: 'auto',
            closeBtnInside: true,
            preloader: false,
            midClick: true,
            removalDelay: 300,
            mainClass: 'my-mfp-zoom-in'
        });
    });
</script>
</head>
<body>
<?php 
    $active = $this->router->fetch_class();
?>
    <div class="header">
        <div class="">
            <div class="header_top">
                <div class="container">
                    <div class="logo">
                        <a href="<?php echo base_url("home")?>"><img src="<?php echo base_url("assets");?>/images/logo.png" alt=""/></a>
                    </div> 
                    <div class="cssmenu">
                            <ul>
                                <li><a href="mailto:info@mycompany.com">info(at)voucher.com</a></li> 
                                <li class="active"><a href="<?php echo base_url("auth/login")?>">Log In</a></li> 
                                <li><a href="<?php echo base_url("auth/register")?>">Register</a></li>
                            </ul>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="h_menu4"><!-- start h_menu4 -->
            <div class="container">
                <a class="toggleMenu" href="#">Menu</a>
                <ul class="nav">
                    <li <?php echo ($active =="home")? 'class = active':''?>><a href="<?php echo base_url("home")?>">Home</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li <?php echo ($active =="services")? "class='active'" : "" ?>> <a href="<?php echo base_url("services");?>">Service</a></li>
                    <li <?php echo ($active =="store")? 'class = active':''?> class="dropdown">
                      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Store<span class="caret"></span></a>
                      <ul class="dropdown-menu">
                        <li><a class="droplink" href="<?php echo base_url("store/details")?>">Detail</a></li>
                        <li><a class="droplink" href="<?php echo base_url("store/theme")?>">Theme</a></li>
                      </ul>
                    </li>
                    <li <?php echo ($active =="promo")? "class='active'" : "" ?>> <a href="<?php echo base_url("promo");?>">Promo</a></li>
                    <li <?php echo ($active =="reseller")? "class='active'" : "" ?>> <a href="<?php echo base_url("reseller");?>">Reseller</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                 </ul>
                 <script type="text/javascript" src="<?php echo base_url("assets");?>/js/nav.js"></script>
            </div>

            </div><!-- end h_menu4 -->
         </div>
    </div>