<div class="about">
	 <div class="container">
		<h1>Our Service<span class="m_1"><br>What we Doing</span></h1>
	</div>
</div>
<div class="about_grid">
	<div class="container">
		<h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Hosting<br></span>Services</p>
        </h4>
		<div class="service_box">
			<div class="col-md-4 service_grid1">
				<i class="icon1"> </i>
				<h3>Unlimited Disk Space</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="col-md-4 service_grid1">
				<i class="icon2"> </i>
				<h3>Unlimited Bandwidth</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="col-md-4 service_grid1">
				<i class="icon3"> </i>
				<h3>27/7 Customer Support</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="service_box1">
			<div class="col-md-4 service_grid1">
				<i class="icon4"> </i>
				<h3>High Speed</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="col-md-4 service_grid1">
				<i class="icon5"> </i>
				<h3>Site Protections</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="col-md-4 service_grid1">
				<i class="icon6"> </i>
				<h3>SSD Database Storage</h3>
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="about_grid1">
	<div class="container">
		<div class="col-md-7">
			<h4 class="tz-title-4 tzcolor-blue">
               <p class="tzweight_Bold"><span class="m_1">Featured<br></span>Services</p>
            </h4>
        	<div class="service_box2">
				<div class="lsidebar span_1_of_about">
					<img src="<?php echo base_url("assets");?>/images/s1.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="cont span_2_of_about">
					<h3><a href="domain.html">Domain</a></h3>
				    <p>Kami memberikan Full control untuk domain Anda. Tidak ada syarat tersembunyi, tidak ada peraturan lock domain, atau semua keruwetan seperti provider hosting murah sebelah. So, kenapa harus beli di tempat lain, jika di SmartMedia lebih baik? </p>
				</div>
				<div class="clearfix"></div>	
			</div>
			<div class="service_box2">
				<div class="lsidebar span_1_of_about">
					<img src="<?php echo base_url("assets");?>/images/s1.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="cont span_2_of_about">
					<h3><a href="plans.html">Hosting</a></h3>
				    <p>Setiap website pasti membutuhkan server hosting online agar bisa diakses melalui internet. Untuk itu kami memberikan solusi untuk Anda yang ingin website Anda bisa diakses melalui internet (online) dengan menyewakan space hosting murah. </p>
				</div>
				<div class="clearfix"></div>	
			</div>
			<div class="service_box3">
				<div class="lsidebar span_1_of_about">
					<img src="<?php echo base_url("assets");?>/images/s1.jpg" class="img-responsive" alt=""/>
				</div>
				<div class="cont span_2_of_about">
					<h3><a href="webmail.html">Web Mail</a></h3>
				    <p>Email hosting memungkinkan Anda untuk memiliki email dengan alamat nama perusahaan Anda (nama_anda@namaperusahaan). Dengan layanan Email hosting, Anda bisa mempromosikan perusahaan Anda dengan mudah kepada rekan bisnis dan calon pelanggan Anda.</p>
				</div>
				<div class="clearfix"></div>	
			</div>
        </div>
        <div class="col-md-5">
        	<h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Latest<br></span>News</p>
        </h4>
        	<ul class="project_box">
			  <li class="mini-post-meta"><time datetime=""><span class="day">1</span><span class="month">Jan-05</span></time></li>
			  <li class="desc"><h5><a href="#">News Heading Here</a></h5>
			  	 <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
			  </li>	
			  <div class="clearfix"> </div>
			</ul>
			<ul class="project_box">
			  <li class="mini-post-meta"><time datetime=""><span class="day">2</span><span class="month">Jan-05</span></time></li>
			  <li class="desc"><h5><a href="#">News Heading Here</a></h5>
			  	 <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
			  </li>	
			  <div class="clearfix"> </div>
			</ul>
			<ul class="project_box">
			  <li class="mini-post-meta"><time datetime=""><span class="day">3</span><span class="month">Jan-05</span></time></li>
			  <li class="desc"><h5><a href="#">News Heading Here</a></h5>
			  	 <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>
			  </li>	
			  <div class="clearfix"> </div>
			</ul>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<div class="about_grid">
	<div class="container">
		<h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Happy<br></span>Clients</p>
        </h4>
		<div class="wmuSlider example1">
			<div class="wmuSliderWrapper">
				<article style="position: absolute; width: 100%; opacity: 0;"> 
				   	   <div class="banner-wrap">
				   	 	   <ul class="grid-1">
				   	 			<li class="grid-1_left">
				   	 				<img src="<?php echo base_url("assets");?>/images/freestock/people1.jpg" class="img-responsive" alt="" width="150px" />
				   	 			</li>
				   	 			<li class="grid-1_right">
				   	 				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged</p>
								    <h4>By<br><span class="m_10">Leap Designer</span></h4>
				   	 			</li>
				   	 			<div class="clearfix"> </div>
				   	 		</ul>
				   	   </div>
				   </article>
				   <article style="position: absolute; width: 100%; opacity: 0;"> 
				   	   <div class="banner-wrap">
				   	 	   <ul class="grid-1">
				   	 			<li class="grid-1_left">
				   	 				<img src="<?php echo base_url("assets");?>/images/freestock/people2.jpg" class="img-responsive" alt="" width="150px" />
				   	 			</li>
				   	 			<li class="grid-1_right">
				   	 				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged</p>
								    <h4>By<br><span class="m_10">Leap Designer</span></h4>
				   	 			</li>
				   	 			<div class="clearfix"> </div>
				   	 		</ul>
				   	   </div>
				   </article>
				    <article style="position: absolute; width: 100%; opacity: 0;"> 
				   	   <div class="banner-wrap">
				   	 	   <ul class="grid-1">
				   	 			<li class="grid-1_left">
				   	 				<img src="<?php echo base_url("assets");?>/images/freestock/people3.jpg" class="img-responsive" alt="" width="150px" />
				   	 			</li>
				   	 			<li class="grid-1_right">
				   	 				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged</p>
								    <h4>By<br><span class="m_10">Leap Designer</span></h4>
				   	 			</li>
				   	 			<div class="clearfix"> </div>
				   	 		</ul>
				   	   </div>
				   </article>
				</div>
			    <ul class="wmuSliderPagination">
                	<li><a href="#" class="">0</a></li>
                	<li><a href="#" class="">1</a></li>
                	<li><a href="#" class="wmuActive">2</a></li>
                </ul>
            </div>
            <script src="<?php echo base_url("assets");?>/js/jquery.wmuSlider.js"></script> 
			  <script>
       			$('.example1').wmuSlider();         
   		     </script> 	           	      
	</div>
</div>
<div class="domain">
	<div class="container">
		<form class="search-form domain-search">
			<div class="two-fifth signup column first">
			    <img src="<?php echo base_url("assets");?>/images/msg.png" alt=""/>
			    <h2><span class="m_1">Sign Up Your</span><br>Newsletter</h2>
			</div>
            <div class="three-fifth searchbar column first">
                <input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
            </div>
            <div class="one-fifth col_2 ">
                <input type="submit" value="Sign Up Now">
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>