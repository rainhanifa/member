<div class="about">
	 <div class="container">
		<h1>Promo<span class="m_1"><br>Saat ini</span></h1>
	</div>
</div>
<div class="promo-container">
	<div class="container">
		<div class="testimonial_grid">
			<h3> Promo Gratis Merchandise</h3>
	        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. </p>
	                     	  
	    </div>

	    <div class="testimonial_grid">
			<h3> Promo Gratis Merchandise</h3>
	        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. </p>
	                     	  
	    </div>

	    <div class="testimonial_grid">
			<h3> Promo Gratis Merchandise</h3>
	        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. </p>
	                     	  
	    </div>

	     <div class="testimonial_grid">
			<h3> Promo Gratis Merchandise</h3>
	        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. </p>
	                     	  
	     </div>
	</div>
</div>
<div class="domain">
    <div class="container">
        <form class="search-form domain-search">
            <div class="two-fifth signup column first">
                <img src="<?php echo base_url("assets");?>/images/msg.png" alt=""/>
                <h2><span class="m_1">Sign Up Your</span><br>Newsletter</h2>
            </div>
            <div class="three-fifth searchbar column first">
                <input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
            </div>
            <div class="one-fifth col_2 ">
                <input type="submit" value="Sign Up Now">
            </div>
                <div class="clearfix"> </div>
        </form>
    </div>
</div>