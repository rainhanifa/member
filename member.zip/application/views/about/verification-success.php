<div class="account_grid">
	<div class="container">
		<div class="col-md-12 login-left">
			<h4 class="tz-title-5 tzcolor-blue">
                <p class="tzweight_Bold"><span class="m_20">Verifikasi Berhasil</span></p>
            </h4>
			<p>Login untuk melanjutkan</p>
		</div>
		<div class="col-md-4 login-right">
      		<form action="kode-voucher.html">
	        	<div>
					<span class="m_25">Email Address<label>*</label></span>
					<input type="text"> 
				</div>
				<div>
					<span class="m_25">Password<label>*</label></span>
					<input type="text"> 
				</div>
				<input type="submit" value="Login">
			</form>
		</div>	
		<div class="clearfix"> </div>
    </div>
</div>