<br/>
	<div class="container">
		<div class="col-md-12 login-left">
			<h4 class="tz-title-5 tzcolor-blue">
            	<p class="tzweight_Bold"><span class="m_20">Registrasi Berhasil</span></p>
            </h4>
			<p>Email telah dikirimkan ke <a href="<?php echo base_url("auth/verification");?>">youmail@gmail.com</a></p>
		</div>
    </div>
<br/>
<br/>
<br/>