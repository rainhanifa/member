<div class="about">
	 <div class="container">
		<h1>Blog<span class="m_1"><br>Page</span></h1>
	</div>
</div>
<div class="about_grid">
	<div class="container">
		<h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Our<br></span>Blog</p>
        </h4>
        <div class="blog">
	        <div class="blog_top">
	           <a href="single.html"><img src="<?php echo base_url("assets");?>/images/b1.jpg" class="img-responsive" alt=""/></a>
	           <h3><a href="single.html">Blog Heading Here</a></h3>
	           <h4>Posted By : <a href="single.html">Ipsum</a> | Date : 03-03-2015</h4>
	           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, </p>
	           <a class="faq_but1" href="single.html">Read More</a>
	           <div class="links">
		  		  <ul class="blog_links">
		  			<li><a href="#"><i class="blog_circle">24 </i><span>Comments</span></a></li>
		  			<li><a href="#"><i class="blog_icon1"> </i><span>Like</span></a></li>
		  		  </ul>
		  		  <ul class="blog_social">
					  <li class="share"><i class="blog_icon2"> </i><p class="share_text">Share : </p></li>
					  <li><a href="#"> <i class="fb2"> </i> </a></li>
					  <li><a href="#"> <i class="tw2"> </i> </a></li>
					  <li><a href="#"> <i class="linked"> </i></a></li>
					  <li><a href="#"> <i class="g2"> </i></a></li>
					  <div class="clearfix"> </div>
				  </ul>
		  		  <div class="clearfix"></div>
		  	   </div>
		  	</div>
		  	<div class="blog_top">
	           <a href="single.html"><img src="<?php echo base_url("assets");?>/images/b3.jpg" class="img-responsive" alt=""/></a>
	           <h3><a href="single.html">Blog Heading Here</a></h3>
	           <h4>Posted By : <a href="single.html">Ipsum</a> | Date : 03-03-2015</h4>
	           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, </p>
	           <a class="faq_but1" href="single.html">Read More</a>
	           <div class="links">
		  		  <ul class="blog_links">
		  			<li><a href="#"><i class="blog_circle">24 </i><span>Comments</span></a></li>
		  			<li><a href="#"><i class="blog_icon1"> </i><span>Like</span></a></li>
		  		  </ul>
		  		  <ul class="blog_social">
					  <li class="share"><i class="blog_icon2"> </i><p class="share_text">Share : </p></li>
					  <li><a href="#"> <i class="fb2"> </i> </a></li>
					  <li><a href="#"> <i class="tw2"> </i> </a></li>
					  <li><a href="#"> <i class="linked"> </i></a></li>
					  <li><a href="#"> <i class="g2"> </i></a></li>
					  <div class="clearfix"> </div>
				  </ul>
		  		  <div class="clearfix"></div>
		  	   </div>
		  	</div>
		  	<div class="blog_top">
	           <a href="single.html"><img src="<?php echo base_url("assets");?>/images/b2.jpg" class="img-responsive" alt=""/></a>
	           <h3><a href="single.html">Blog Heading Here</a></h3>
	           <h4>Posted By : <a href="single.html">Ipsum</a> | Date : 03-03-2015</h4>
	           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, </p>
	           <a class="faq_but1" href="single.html">Read More</a>
	           <div class="links">
		  		  <ul class="blog_links">
		  			<li><a href="#"><i class="blog_circle">24 </i><span>Comments</span></a></li>
		  			<li><a href="#"><i class="blog_icon1"> </i><span>Like</span></a></li>
		  		  </ul>
		  		  <ul class="blog_social">
					  <li class="share"><i class="blog_icon2"> </i><p class="share_text">Share : </p></li>
					  <li><a href="#"> <i class="fb2"> </i> </a></li>
					  <li><a href="#"> <i class="tw2"> </i> </a></li>
					  <li><a href="#"> <i class="linked"> </i></a></li>
					  <li><a href="#"> <i class="g2"> </i></a></li>
					  <div class="clearfix"> </div>
				  </ul>
		  		  <div class="clearfix"></div>
		  	   </div>
		  	</div>
		  	<ul class="dc_pagination dc_paginationA dc_paginationA06">
				  <li><a href="#" class="current">1</a></li>
				  <li><a href="#">2</a></li>
				  <li><a href="#">3</a></li>
				  <li><a href="#">4</a></li>
				  <li><a href="#">...</a></li>
				  <li><a href="#">13</a></li>
			</ul>
	    </div>
	 </div>
</div>
<div class="domain">
	<div class="container">
	 	<form class="search-form domain-search">
			<div class="two-fifth signup column first">
				<img src="<?php echo base_url("assets");?>/images/msg.png" alt=""/>
			 	<h2><span class="m_1">Sign Up Your</span><br>Newsletter</h2>
			</div>
            <div class="three-fifth searchbar column first">
                <input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
            </div>
            <div class="one-fifth col_2 ">
                <input type="submit" value="Sign Up Now">
            </div>
            <div class="clearfix"> </div>
        </form>
      </div>
</div>