<div class="about">
	 <div class="container">
		<h1>FAQ<span class="m_1"><br>Questions</span></h1>
	</div>
</div>
<div class="about_grid">
	<div class="container">
		<h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Question<br></span>FAQ'S</p>
        </h4>
        <div class="faq_top">
		<div class="plans_grid">
		    <div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">Lorem Ipsum is simply dummy text of the print ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">opposed to using 'Content here, content here ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="plans_grid">
		    <div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">There are many variations of passages of Lorem ?</a></h5>
				  	 <p> embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">making this the first true generator on the ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="plans_grid">
		    <div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">standard chunk of Lorem Ipsum used since ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">opposed to using 'Content here, content here ?</a></h5>
				  	 <p>psum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="plans_grid">
		    <div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">Lorem Ipsum is simply dummy text of the print ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book. It has survived not only five centuries. but also the leap into electronic typesetting, remaining essentially unchanged.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="col-md-6">
				<ul class="project_box">
				  <li class="mini-post-meta2">Q</li>
				  <li class="desc"><h5><a href="#">opposed to using 'Content here, content here ?</a></h5>
				  	 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the when an unknown printer took a galley of type and scrambled it to make. a type specimen book.</p>
				  </li>	
				  <div class="clearfix"> </div>
				</ul>
			</div>
			<div class="clearfix"> </div>
		</div>
		<div class="faq_but">
		  <a class="faq_but1" href="#">Ask Our Questions Through Email</a>
	    </div>
	  </div>
	  <div class="faq_bottom">
	  	   <h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">Submit Your<br></span>Questions</p>
          </h4>
	  	   <form>
				<div class="form_list1">
		            <input type="text" class="text" value="Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name';}">
					<input type="text" class="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" style="margin-left:2%">
				</div>
				<div class="form_list2">
					<input type="text" class="text" value="Subject" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Subject';}">
				</div>
				<div class="form_list3">
			        <textarea value="Ask your questions here" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Message';}">Ask your questions here</textarea>
			    </div>
			    <div class="form-submit">
					<input name="submit" type="submit" id="submit" value="Submit"><br>
				</div>
				<div class="clearfix"></div>
          </form>
	  </div>
    </div>
</div>
<div class="domain">
	<div class="container">
		<form class="search-form domain-search">
			<div class="two-fifth signup column first">
			    <img src="<?php echo base_url("assets");?>/images/msg.png" alt=""/>
			    <h2><span class="m_1">Sign Up Your</span><br>Newsletter</h2>
			</div>
            <div class="three-fifth searchbar column first">
            	<input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
            </div>
            <div class="one-fifth col_2 ">
            	<input type="submit" value="Sign Up Now">
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>