
    <div class="banner">
        <div class="container">

           <!-- FlexSlider -->
           <section class="slider">
               <div class="flexslider">
                    <ul class="slides">
                        <li>
                            <img src="<?php echo base_url("assets");?>/images/freestock/hero-1.jpg" class="" alt=""/>
                        </li>
                        <li>
                            <img src="<?php echo base_url("assets");?>/images/freestock/hero-2.jpg" class="" alt=""/>
                        </li>
                    </ul>
                </div>
            </section>
            <!-- FlexSlider -->

        </div>
    </div>
    <div class="domain">
        <div class="container">
            <form class="search-form domain-search">
                <div class="two-fifth column first">
                    <img src="<?php echo base_url("assets");?>/images/search.png" alt=""/>
                    <h2><span class="m_1">search your</span><br>domain</h2>
                </div>
                <div class="three-fifth column first">
                    <input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
                </div>
                <div class="one-fifth column">
                    <span class="selection-box"><select class="domains valid" name="domains">
                        <option>Year(0-1 Year)</option>
                        <option>.info (From $3 / Year)</option>
                        <option>.net (From $3 / Year)</option>
                        <option>.org (From $3 / Year)</option>
                    </select></span>
                </div>
                <div class="one-fifth column">
                    <span class="selection-box"><select class="domains valid" name="domains">
                        <option>.com</option>
                        <option>.info (From $3 / Year)</option>
                        <option>.net (From $3 / Year)</option>
                        <option>.org (From $3 / Year)</option>
                    </select></span>
                </div>
                <div class="one-fifth column">
                    <input type="submit" value="Search">
                </div>
                <div class="clearfix"> </div>
            </form>
        </div>
    </div>
    <div class="benefit">
        <div class="container">
            <h4 class="tz-title-4 tzcolor-blue">
                <p class="tzweight_Bold"><span class="m_1">our<br></span>Benefits</p>
            </h4>
            <div class="box1">
                <div class="col-md-4 row_10">
                    <ul class="service_grid">
                       <i class="fa fa-circle-o-notch" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>99.9% Uptime</h3>
                        <p>Service Level Agreement (SLA) dari SmartMedia adalah 99,99% mencakup Up-time layanan & koneksi jaringan..</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="service_grid">
                       <i class="fa fa-commenting-o" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>24/7/365 Support</h3>
                        <p>We're always here to assist via email, LiveChat, and telephone!.</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="service_grid">
                       <i class="fa fa-desktop" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>Protect Your pc</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
            </div>
            <div class="box1">
                <div class="col-md-4">
                    <ul class="service_grid">
                       <i class="fa fa-cogs" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>Website Builder</h3>
                        <p>Instant access to our state of the art drag and drop website editor. Choose from 100s of professional looking templates..</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="service_grid">
                       <i class="fa fa-cloud" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>Domain Transfer</h3>
                        <p>We'll move your site, or sites, free of charge with our white-glove migration service..</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
                <div class="col-md-4">
                    <ul class="service_grid">
                       <i class="fa fa-unlock-alt fa-inc-left" aria-hidden="true"></i>
                       <li class="desc">
                        <h3>100% Security</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                       </li>
                       <div class="clearfix"> </div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="features">
        <div class="container">
            <div class="col-md-4">
               <h4 class="tz-title-4 tzcolor-blue">
                 <p class="tzweight_Bold m_2"><span class="m_1">Now<br></span>What is Hot</p>
              </h4>
              <ul class="offer">
                 <li><p class="m_3"><span class="m_4">Get Up to<br></span>50%</p></li>	
                 <li><p class="m_5">Off</p></li>	
                 <li class="last"><p class="m_6"><span class="m_7">Each<br></span>Hosting</p></li>
              </ul>
            </div>
            <div class="col-md-8 row_1">
                <h4 class="tz-title-4 tzcolor-blue">
                 <p class="tzweight_Bold m_2"><span class="m_1">our<br></span>Feature</p>
               </h4>
               <div class="section_1">
                <div class="col_1_of_3 span_1_of_3">
                    <div class="list_1">
                        <ul>
                          <li><a href="">Unlimited Email.</a></li>
                          <li><a href="">cPanel Control Panel.</a></li>                           
                          <li><a href="">LiteSpeed Enterprise.</a></li>      
                          <li><a href="">SSH, GIT, Addon Domain.</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col_1_of_3 span_1_of_3">
                    <div class="list_1">
                        <ul>
                        <li><a href="">Free Backup Daily.</a></li>  
                          <li><a href="">Website Builder.</a></li>
                          <li><a href="">Instant Backup, dll.</a></li>
                          <li><a href="">MySQL, PHPMyAdmin, dll.</a></li>
                           
                        </ul>
                    </div>
                </div>
                <div class="col_1_of_3 span_1_of_3">
                    <a class="but1" href="#">View All</a>
                </div>
                <div class="clearfix"> </div>
               </div>
            </div>
        </div>
    </div>
    <div class="price">
        <div class="container">
            <h4 class="tz-title-4 tzcolor-blue">
                <p class="tzweight_Bold"><span class="m_1">our<br></span>Benefits</p>
            </h4>
            <div class="col-md-3">
                <div class="pricing-table-grid">
                    <h3><span class="dollar">Rp </span>15<span class="dollar">rb</span> <br><span class="month">Per Bulan</span></h3>
                    <ul>
                        <li><span>Standard Plan</span></li>
                        <li><a href="#">500 MB Storage</a></li>
                        <li><a href="#">256 MB Virtual Memory</a></li>
                        <li><a href="#">Half Core CPU</a></li>
                        <li><a href="#">Managed Hosting</a></li>
                        <li><a href="#">Unlimited Bandwidth</a></li>
                    </ul>
                    <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Order</a>
                </div>
                <div id="small-dialog" class="mfp-hide">
                    <div class="pop_up">
                        <div class="payment-online-form-left">
                            <form>
                                <h4><span class="shipping"> </span>Shipping</h4>
                                <ul>
                                    <li><input class="text-box-dark" type="text" value="Frist Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Frist Name';}"></li>
                                    <li><input class="text-box-dark" type="text" value="Last Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Last Name';}"></li>
                                </ul>
                                <ul>
                                    <li><input class="text-box-dark" type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"></li>
                                    <li><input class="text-box-dark" type="text" value="Company Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Company Name';}"></li>
                                </ul>
                                <ul>
                                    <li><input class="text-box-dark" type="text" value="Phone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone';}"></li>
                                    <li><input class="text-box-dark" type="text" value="Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Address';}"></li>
                                    <div class="clearfix"> </div>
                                </ul>
                                <div class="clear"> </div>
                            <ul class="payment-type">
                                <h4><span class="payment"> </span> Payments</h4>
                                <li>
                                    <span class="col_checkbox">
                                    <input id="3" class="css-checkbox1" type="checkbox">
                                    <label for="3" name="demo_lbl_1" class="css-label1"> </label>
                                    <a class="visa" href="#"> </a>
                                    </span>
                                </li>
                                <li>
                                    <span class="col_checkbox">
                                        <input id="4" class="css-checkbox2" type="checkbox">
                                        <label for="4" name="demo_lbl_2" class="css-label2"> </label>
                                        <a class="paypal" href="#"> </a>
                                    </span>
                                </li>
                                <div class="clearfix"> </div>
                            </ul>
                                <ul>
                                    <li><input class="text-box-dark" type="text" value="Card Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Card Number';}"></li>
                                    <li><input class="text-box-dark" type="text" value="Name on card" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name on card';}"></li>
                                    <div class="clearfix"> </div>
                                </ul>
                                <ul>
                                    <li><input class="text-box-light hasDatepicker" type="text" id="datepicker" value="Expiration Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Expiration Date';}"><em class="pay-date"> </em></li>
                                    <li><input class="text-box-dark" type="text" value="Security Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Security Code';}"></li>
                                    <div class="clearfix"> </div>
                                </ul>
                                <ul class="payment-sendbtns">
                                    <li><input type="reset" value="Cancel"></li>
                                    <li><input type="submit" value="Process order"></li>
                                </ul>
                                <div class="clearfix"> </div>
                            </form>
                        </div>
                    </div>
                </div>
             </div>
             <div class="col-md-3">
                <div class="pricing-table-grid">
                    <h3><span class="dollar">Rp </span>100<span class="dollar">rb</span> <br><span class="month">Per Bulan</span></h3>
                    <ul>
                        <li><span>Advanced Plan</span></li>
                        <li><a href="#">1 GB Storage</a></li>
                        <li><a href="#">Indonesia Data Center</a></li>
                        <li><a href="#">256 MB Virtual Memory</a></li>
                        <li><a href="#">Single Core CPU</a></li>
                        <li><a href="#">Unlimited Bandwidth</a></li>
                    </ul>
                    <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Order</a>
                </div>
             </div>	
             <div class="col-md-3">
                <div class="pricing-table-grid">
                    <h3><span class="dollar">Rp </span>400<span class="dollar">rb</span> <br><span class="month">Per Bulan</span></h3>
                    <ul>
                        <li><span>Business Plan</span></li>
                        <li><a href="#">60 GB Storage</a></li>
                        <li><a href="#">Free cPanel/WHM</a></li>
                        <li><a href="#">1024 MB Virtual Memory</a></li>
                        <li><a href="#">Single Core CPU</a></li>
                        <li><a href="#">Unlimited Bandwidth</a></li>
                    </ul>
                    <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Order</a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="pricing-table-grid">
                    <h3><span class="dollar">Rp </span>1000<span class="dollar">rb</span> <br><span class="month">Per Bulan</span></h3>
                    <ul>
                        <li><span>Gold Plan</span></li>
                        <li><a href="#">SATA 2x1 TB Storage</a></li>
                        <li><a href="#">Indonesia Data Center</a></li>
                        <li><a href="#">DDR3 16GB Virtual Memory</a></li>
                        <li><a href="#">3.3 GHZ CPU</a></li>
                        <li><a href="#">Unlimited Bandwidth</a></li>
                    </ul>
                    <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Order</a>
                </div>
            </div>	
            <div class="clearfix"> </div>								
       </div>
    </div>
    <div class="domain">
        <div class="container">
            <form class="search-form domain-search" action="register.html">
                <div class="two-fifth signup column first">
                    <img src="<?php echo base_url("assets");?>/images/msg.png" alt=""/>
                    <h2><span class="m_1">Sign Up Your</span><br>Newsletter</h2>
                </div>
                <div class="three-fifth searchbar column first">
                    <input type="text" class="text" value="Enter your domain name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">               
                </div>
                <div class="one-fifth col_2 ">
                    <input type="submit" value="Sign Up Now">
                </div>
                <div class="clearfix"> </div>
            </form>
        </div>
    </div>

    <link href="<?php echo base_url("assets");?>/css/flexslider.css" rel='stylesheet' type='text/css' />
        <script defer src="<?php echo base_url("assets");?>/js/jquery.flexslider.js"></script>
        <script type="text/javascript">
            $(function(){
                SyntaxHighlighter.all();
            });
            $(window).load(function(){
                $('.flexslider').flexslider({
                    animation: "slide",
                    start: function(slider){
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
    